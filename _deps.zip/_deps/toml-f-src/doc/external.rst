.. _external:

External resources
==================

Sites and blog posts with information on TOML Fortran are mentioned and linked here.


.. toctree::

   Modern Fortran by Philipp Engel (English) <https://cyber.dabamos.de/programming/modernfortran/toml.html>
   Fortran in Action by Zuo Zhihua (Chinese) <https://fortran-fans.github.io/Fortran-in-Action/Using-Open-Source-Code/Project-Configuration-TOML-F.html>
