Reference documentation
=======================

This section contains the detailed technical specification for TOML Fortran or the TOML language itself.

.. toctree::

   TOML specification <https://toml.io/en/v1.0.0>
   API documentation <https://toml-f.github.io/toml-f>
