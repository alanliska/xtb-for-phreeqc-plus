.. _api:

Public API documentation
========================

.. toctree::

   fortran
   c
   python
