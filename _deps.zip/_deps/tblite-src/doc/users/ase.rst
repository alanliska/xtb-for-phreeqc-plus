.. _ase-calc:

Usage in ASE
============

.. automodule:: tblite.ase


ASE calculator
--------------

.. autoclass:: TBLite
   :members:
