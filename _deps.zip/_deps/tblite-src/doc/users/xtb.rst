Usage in xtb
============

The *tblite* project originated from the `xtb`_ program package.\ :footcite:`bannwarth2020`

.. note::

   Support in ``xtb`` is planned for the version 6.5.0 release.

.. _xtb: https://github.com/grimme-lab/xtb


Literature
----------

.. footbibliography::
