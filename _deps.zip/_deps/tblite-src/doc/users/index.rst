.. _integration:

Available integrations
======================

The following packages are currently using or in the process of integrating *tblite*:

.. toctree::

   xtb
   dftbplus
   qcxms
   ase
