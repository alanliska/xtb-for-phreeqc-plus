# DFT-D4 on the Arch User Repository (AUR)

[![AUR stable](https://img.shields.io/aur/version/dftd4?label=dftd4)](https://aur.archlinux.org/packages/dftd4/)
[![AUR git](https://img.shields.io/aur/version/dftd4-git?label=dftd4-git)](https://aur.archlinux.org/packages/dftd4-git/)

This program is available for Arch Linux via the [AUR](https://aur.archlinux.org).
The necessary `PKGBUILD` files are provided here as git submodules linking
to the AUR.

Detailed information for packaging for the AUR can be found in the Arch Linux Wiki.
