#ifndef mctc_defs_fh
#define mctc_defs_fh

#ifndef WITH_JSON
#define WITH_JSON 1
#endif

#endif
