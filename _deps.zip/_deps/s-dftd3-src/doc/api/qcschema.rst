.. automodule:: dftd3.qcschema
